"""GitHub integration modules."""
