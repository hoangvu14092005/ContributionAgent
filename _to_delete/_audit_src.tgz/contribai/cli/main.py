"""ContribAI CLI - Rich command-line interface.

Usage:
    contribai run           Auto-discover repos and contribute
    contribai target <url>  Target a specific repo
    contribai analyze <url> Analyze a repo without contributing
    contribai solve <url>   Solve issues in a specific repo
    contribai status        Show status of submitted PRs
    contribai stats         Show overall statistics
    contribai config        Show current configuration
"""

from __future__ import annotations

import asyncio
import logging
import sys

import click
from rich.console import Console
from rich.logging import RichHandler
from rich.panel import Panel
from rich.table import Table

from contribai import __version__
from contribai.core.config import load_config

# Fix Windows console encoding for emoji/unicode support
if sys.platform == "win32":
    import os

    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")

console = Console()


def setup_logging(verbose: bool = False):
    level = logging.DEBUG if verbose else logging.INFO
    handlers: list[logging.Handler] = [
        RichHandler(console=console, show_path=False, rich_tracebacks=True)
    ]

    # Add file logging for persistence
    try:
        from pathlib import Path

        log_dir = Path.home() / ".contribai"
        log_dir.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_dir / "contribai.log", encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)-8s %(name)s: %(message)s")
        )
        handlers.append(file_handler)
    except Exception:
        pass  # Don't fail if file logging can't be set up

    logging.basicConfig(
        level=level,
        format="%(message)s",
        handlers=handlers,
    )


# def print_banner():
#     banner = f"""[bold cyan]
#    ____            _        _ _      _    ___
#   / ___|___  _ __ | |_ _ __(_) |__  / \\  |_ _|
#  | |   / _ \\| '_ \\| __| '__| | '_ \\/ _ \\  | |
#  | |__| (_) | | | | |_| |  | | |_) / ___ \\ | |
#   \\____\\___/|_| |_|\\__|_|  |_|_.__/_/   \\_\\___|

#   [dim]AI Agent for Open Source Contributions v{__version__}[/dim]
# [/bold cyan]"""
#     console.print(banner)

def print_banner():
    banner = f"""[bold cyan]
   _          _____ _                 _     _____ _     _       _
  | |    ___ |_   _| |__   __ _ _ __ | |_  / ____| |__ (_)_ __ | |__
  | |   / _ \\  | | | '_ \\ / _` | '_ \\| __|| |    | '_ \\| | '_ \\| '_ \\
  | |__|  __/  | | | | | | (_| | | | | |_ | |____| | | | | | | | | | |
  |_____\\___|  |_| |_| |_|\\__,_|_| |_|\\__(_)_____|_| |_|_|_| |_|_| |_|

  [dim]AI Agent for Open Source Contributions v{__version__}[/dim]
[/bold cyan]"""
    console.print(banner)


@click.group()
@click.option("--config", "-c", type=click.Path(), default=None, help="Config file path")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
@click.pass_context
def cli(ctx, config, verbose):
    """ContribAI - AI Agent that contributes to open source projects."""
    ctx.ensure_object(dict)
    setup_logging(verbose)
    ctx.obj["config_path"] = config
    ctx.obj["verbose"] = verbose


@cli.command()
@click.option("--language", "-l", multiple=True, help="Filter by language(s)")
@click.option("--stars", "-s", default=None, help="Star range (e.g., 100-5000)")
@click.option("--max-prs", "-m", type=int, default=None, help="Max PRs to create")
@click.option("--dry-run", is_flag=True, help="Analyze and generate without creating PRs")
@click.option("--human-review", is_flag=True, help="Pause for human approval before each PR")
@click.option("--events-log", type=click.Path(), default=None, help="Write events to JSONL file")
@click.pass_context
def run(ctx, language, stars, max_prs, dry_run, human_review, events_log):
    """Auto-discover repositories and create contributions."""
    print_banner()

    config = load_config(ctx.obj["config_path"])

    # Apply CLI overrides
    if language:
        config.discovery.languages = list(language)
    if stars:
        parts = stars.split("-")
        config.discovery.stars_range = [int(parts[0]), int(parts[1])]
    if max_prs:
        config.github.max_prs_per_day = max_prs

    if not config.github.token:
        console.print("[red]❌ GitHub token not configured![/red]")
        console.print("Set it in config.yaml or run: contribai config set github.token <token>")
        sys.exit(1)

    if not config.llm.api_key and not config.llm.use_vertex:
        console.print("[red]❌ LLM API key not configured![/red]")
        sys.exit(1)

    mode = "[yellow]DRY RUN[/yellow]" if dry_run else "[green]LIVE[/green]"
    console.print(f"\nStarting ContribAI pipeline ({mode})")
    console.print(f"   Languages: {', '.join(config.discovery.languages)}")
    console.print(f"   Stars: {config.discovery.stars_range[0]}-{config.discovery.stars_range[1]}")
    console.print(f"   LLM: {config.llm.provider} ({config.llm.model})")
    console.print()

    # Apply review gate and events log
    if human_review:
        config.pipeline.human_review = True
        console.print("   🔍 Human review: [green]ENABLED[/green]")
    if events_log:
        console.print(f"   📡 Events log: {events_log}")
    console.print()

    from contribai.orchestrator.pipeline import ContribPipeline

    pipeline = ContribPipeline(config)
    result = asyncio.run(pipeline.run(dry_run=dry_run))

    # Print results
    _print_result(result, dry_run)


@cli.command()
@click.argument("url")
@click.option("--types", "-t", default=None, help="Contribution types (comma-separated)")
@click.option("--dry-run", is_flag=True, help="Analyze and generate without creating PRs")
@click.option("--human-review", is_flag=True, help="Pause for human approval before each PR")
@click.pass_context
def target(ctx, url, types, dry_run, human_review):
    """Target a specific repository for contributions."""
    print_banner()

    config = load_config(ctx.obj["config_path"])

    if types:
        config.contribution.enabled_types = types.split(",")

    if not config.github.token:
        console.print("[red]❌ GitHub token not configured![/red]")
        sys.exit(1)

    if not config.llm.api_key and not config.llm.use_vertex:
        console.print("[red]❌ LLM API key not configured![/red]")
        sys.exit(1)

    mode = "[yellow]DRY RUN[/yellow]" if dry_run else "[green]LIVE[/green]"
    console.print(f"\n🎯 Targeting: {url} ({mode})")
    console.print(f"   LLM: {config.llm.provider} ({config.llm.model})")
    if human_review:
        config.pipeline.human_review = True
        console.print("   🔍 Human review: [green]ENABLED[/green]")
    console.print()

    from contribai.orchestrator.pipeline import ContribPipeline

    pipeline = ContribPipeline(config)
    result = asyncio.run(pipeline.run_single(url, dry_run=dry_run))
    _print_result(result, dry_run)


@cli.command()
@click.option("--rounds", "-r", type=int, default=5, help="Number of discovery rounds")
@click.option("--delay", "-d", type=int, default=30, help="Delay (sec) between rounds")
@click.option("--language", "-l", multiple=True, help="Filter by language(s)")
@click.option(
    "--mode",
    "-m",
    type=click.Choice(["analysis", "issues", "both"]),
    default="both",
    help="Hunt mode: analysis (code scan), issues (solve issues), both",
)
@click.option("--dry-run", is_flag=True, help="Analyze without creating PRs")
@click.option("--human-review", is_flag=True, help="Pause for human approval before each PR")
@click.option("--events-log", type=click.Path(), default=None, help="Write events to JSONL file")
@click.pass_context
def hunt(ctx, rounds, delay, language, mode, dry_run, human_review, events_log):
    """🔥 Hunt mode: auto-discover repos and contribute aggressively.

    Searches GitHub for high-star, active repos that merge external PRs,
    then runs the full pipeline on each. Loops through multiple rounds
    with varied criteria for maximum coverage.

    Modes:
      analysis - Code pattern scanning only (original behavior)
      issues   - Solve open GitHub issues (v2.0.0)
      both     - Do both (default)
    """
    print_banner()

    config = load_config(ctx.obj["config_path"])

    if language:
        config.discovery.languages = list(language)

    if not config.github.token:
        console.print("[red]❌ GitHub token not configured![/red]")
        sys.exit(1)

    if not config.llm.api_key and not config.llm.use_vertex:
        console.print("[red]❌ LLM API key not configured![/red]")
        sys.exit(1)

    mode_label = "[yellow]DRY RUN[/yellow]" if dry_run else "[red]LIVE 🔥[/red]"
    console.print(f"\n🔥 Hunt Mode ({mode_label})")
    console.print(f"   Mode: {mode}")
    console.print(f"   Rounds: {rounds}")
    console.print(f"   Delay: {delay}s between rounds")
    console.print(f"   Languages: {', '.join(config.discovery.languages)}")
    console.print(f"   LLM: {config.llm.provider} ({config.llm.model})")
    if human_review:
        config.pipeline.human_review = True
        console.print("   🔍 Human review: [green]ENABLED[/green]")
    if events_log:
        console.print(f"   📡 Events log: {events_log}")
    console.print()

    from contribai.orchestrator.pipeline import ContribPipeline

    pipeline = ContribPipeline(config)
    result = asyncio.run(pipeline.hunt(rounds=rounds, delay_sec=delay, dry_run=dry_run, mode=mode))
    _print_result(result, dry_run)


@cli.group()
def skills():
    """Discover and inspect .agents/ skills (agents, workflows, knowledge)."""


@skills.command("list")
@click.option(
    "--category",
    "-c",
    type=click.Choice(["agent", "workflow", "knowledge"]),
    default=None,
    help="Filter by category",
)
@click.option("--has-trigger", is_flag=True, help="Show only skills with a trigger")
@click.pass_context
def skills_list(ctx, category, has_trigger):
    """List all skills discovered under .agents/."""
    from contribai.agents.skill_loader import load_default_loader

    loader = load_default_loader()
    all_skills = loader.list_all()

    if category:
        all_skills = [s for s in all_skills if s.category == category]
    if has_trigger:
        all_skills = [s for s in all_skills if s.has_trigger]

    if not all_skills:
        console.print("[yellow]No skills found.[/yellow]")
        return

    table = Table(title=f"Skills ({len(all_skills)})", show_lines=False)
    table.add_column("Category", style="cyan")
    table.add_column("Trigger", style="green")
    table.add_column("Name", style="bold")
    table.add_column("Description", max_width=60)

    for skill in sorted(all_skills, key=lambda s: (s.category, s.name)):
        table.add_row(
            skill.category,
            skill.trigger or "—",
            skill.name,
            skill.description,
        )

    console.print(table)
    cats = loader.categories()
    console.print(
        f"\n[dim]Counts: agents={cats['agent']}  workflows={cats['workflow']}  "
        f"knowledge={cats['knowledge']}[/dim]"
    )


@skills.command("find")
@click.argument("query")
@click.pass_context
def skills_find(ctx, query):
    """Search skills by keyword (matches name, description, body)."""
    from contribai.agents.skill_loader import load_default_loader

    loader = load_default_loader()
    matches = loader.search(query)
    if not matches:
        console.print(f"[yellow]No skills match '{query}'.[/yellow]")
        return

    table = Table(title=f"Matches for '{query}'")
    table.add_column("Category", style="cyan")
    table.add_column("Trigger", style="green")
    table.add_column("Name", style="bold")
    table.add_column("File", style="dim")
    for skill in matches:
        try:
            rel = str(skill.file_path.relative_to(loader.agents_dir.parent))
        except ValueError:
            rel = str(skill.file_path)
        table.add_row(skill.category, skill.trigger or "—", skill.name, rel)
    console.print(table)


@skills.command("show")
@click.argument("name_or_trigger")
@click.pass_context
def skills_show(ctx, name_or_trigger):
    """Show a skill's full body. Accepts name or trigger like /address_pr_comments."""
    from contribai.agents.skill_loader import load_default_loader

    loader = load_default_loader()
    skill = (
        loader.find_by_trigger(name_or_trigger)
        or loader.find_by_name(name_or_trigger)
    )
    if not skill:
        console.print(f"[red]Skill not found:[/red] {name_or_trigger}")
        raise click.exceptions.Exit(code=1)

    header = f"{skill.name}"
    if skill.trigger:
        header += f"  [green]{skill.trigger}[/green]"
    header += f"  [dim]({skill.category})[/dim]"
    console.print(Panel(header, border_style="cyan"))

    if skill.description:
        console.print(f"[bold]Description:[/bold] {skill.description}\n")
    if skill.inputs:
        console.print("[bold]Inputs:[/bold]")
        for inp in skill.inputs:
            opt = "" if inp.required else " (optional)"
            console.print(f"  • {inp.name}: {inp.type}{opt} — {inp.description}")
        console.print()
    console.print(skill.body)


@cli.command()
@click.option("--dry-run", is_flag=True, help="Show pending feedback without responding")
@click.option("--pr", "pr_number", type=int, default=None, help="Check a specific PR number only")
@click.pass_context
def patrol(ctx, dry_run, pr_number):
    """🔍 Patrol: check open PRs for review feedback and auto-respond.

    Scans all open PRs created by ContribAI, reads maintainer review
    comments, generates code fixes, and pushes updates.

    Actions:
      - CODE_CHANGE: Generate fix and push to PR branch
      - QUESTION: Answer maintainer's question
      - STYLE_FIX: Fix naming/formatting issues
      - CLA: Re-sign CLA after pushing fixes
    """
    print_banner()

    config = load_config(ctx.obj["config_path"])

    if not config.github.token:
        console.print("[red]❌ GitHub token not configured![/red]")
        sys.exit(1)

    if not config.llm.api_key and not config.llm.use_vertex:
        console.print("[red]❌ LLM API key not configured![/red]")
        sys.exit(1)

    mode = "[yellow]DRY RUN[/yellow]" if dry_run else "[green]LIVE[/green]"
    console.print(f"\n🔍 PR Patrol ({mode})")
    if pr_number:
        console.print(f"   Filtering: PR #{pr_number}")
    console.print(f"   LLM: {config.llm.provider} ({config.llm.model})\n")

    from contribai.github.client import GitHubClient
    from contribai.llm.provider import create_llm_provider
    from contribai.orchestrator.memory import Memory
    from contribai.pr.patrol import PRPatrol

    async def _patrol():
        memory = Memory(config.storage.resolved_db_path)
        await memory.init()
        github = GitHubClient(token=config.github.token)
        llm = create_llm_provider(config.llm)

        try:
            # Get all open PRs from memory
            pr_records = await memory.get_prs(status="open", limit=100)
            if not pr_records:
                console.print("[dim]No open PRs found in database.[/dim]")
                return

            console.print(f"📋 Found {len(pr_records)} open PR(s) to check\n")

            patrol_engine = PRPatrol(github=github, llm=llm)
            result = await patrol_engine.patrol(pr_records, dry_run=dry_run, pr_filter=pr_number)

            # Print results
            console.print()
            console.print(
                Panel(
                    f"🔍 PRs checked: [bold]{result.prs_checked}[/bold]\n"
                    f"⏭️  PRs skipped: [bold]{result.prs_skipped}[/bold]\n"
                    f"🛠️  Fixes pushed: [bold]{result.fixes_pushed}[/bold]\n"
                    f"💬 Replies sent: [bold]{result.replies_sent}[/bold]\n"
                    f"✍️  CLA signed: [bold]{result.cla_signed}[/bold]\n"
                    f"📌 Issues assigned: [bold]{result.issues_found}[/bold]"
                    + (f"\n❌ Errors: [red]{len(result.errors)}[/red]" if result.errors else ""),
                    title="🔍 Patrol Complete" + (" (DRY RUN)" if dry_run else ""),
                )
            )

            if result.assigned_issues:
                console.print("\n[bold]📌 Assigned Issues:[/bold]")
                for iss in result.assigned_issues:
                    console.print(
                        f"  • [cyan]{iss['repo']}[/cyan] #{iss['number']}: {iss['title'][:60]}"
                    )
                    console.print(f"    [dim]{iss['url']}[/dim]")

            if result.errors:
                for e in result.errors:
                    console.print(f"  • [red]{e}[/red]")

        finally:
            await github.close()
            await llm.close()
            await memory.close()

    asyncio.run(_patrol())


@cli.command()
@click.argument("url")
@click.pass_context
def analyze(ctx, url):
    """Analyze a repository without creating contributions."""
    print_banner()

    config = load_config(ctx.obj["config_path"])

    if not config.github.token:
        console.print("[red]❌ GitHub token not configured![/red]")
        sys.exit(1)

    if not config.llm.api_key and not config.llm.use_vertex:
        console.print("[red]❌ LLM API key not configured![/red]")
        sys.exit(1)

    console.print(f"\n🔬 Analyzing: {url}")
    console.print(f"   LLM: {config.llm.provider} ({config.llm.model})\n")

    from contribai.orchestrator.pipeline import ContribPipeline

    pipeline = ContribPipeline(config)
    result = asyncio.run(pipeline.analyze_only(url))

    if not result:
        console.print("[red]Analysis failed[/red]")
        return

    # Display findings
    console.print(
        Panel(
            f"Analyzed [bold]{result.analyzed_files}[/bold] files "
            f"in [bold]{result.analysis_duration_sec:.1f}s[/bold]\n"
            f"Skipped {result.skipped_files} files\n"
            f"Found [bold]{len(result.findings)}[/bold] issues",
            title=f"📊 Analysis: {result.repo.full_name}",
        )
    )

    if result.findings:
        table = Table(title="Findings", show_lines=True)
        table.add_column("Severity", style="bold", width=10)
        table.add_column("Type", width=15)
        table.add_column("Title", width=35)
        table.add_column("File", width=25)

        severity_colors = {
            "critical": "red",
            "high": "yellow",
            "medium": "cyan",
            "low": "dim",
        }

        for f in result.top_findings:
            color = severity_colors.get(f.severity.value, "white")
            table.add_row(
                f"[{color}]{f.severity.value.upper()}[/{color}]",
                f.type.value,
                f.title,
                f.file_path[:25],
            )

        console.print(table)


@cli.command()
@click.argument("url")
@click.option("--max-issues", "-n", type=int, default=5, help="Max issues to process")
@click.option("--dry-run", is_flag=True, help="Analyze issues without creating PRs")
@click.pass_context
def solve(ctx, url, max_issues, dry_run):
    """Solve open issues in a specific repository."""
    print_banner()

    config = load_config(ctx.obj["config_path"])

    if not config.github.token:
        console.print("[red]❌ GitHub token not configured![/red]")
        sys.exit(1)

    if not config.llm.api_key and not config.llm.use_vertex:
        console.print("[red]❌ LLM API key not configured![/red]")
        sys.exit(1)

    mode = "[yellow]DRY RUN[/yellow]" if dry_run else "[green]LIVE[/green]"
    console.print(f"\n🎯 Solving issues in: {url} ({mode})")
    console.print(f"   Max issues: {max_issues}")
    console.print(f"   LLM: {config.llm.provider} ({config.llm.model})\n")

    from contribai.github.client import GitHubClient
    from contribai.issues.solver import IssueSolver
    from contribai.llm.provider import create_llm_provider

    async def _solve():
        parts = url.rstrip("/").split("/")
        owner, repo_name = parts[-2], parts[-1]

        llm = create_llm_provider(config.llm)
        github = GitHubClient(token=config.github.token)

        try:
            _repo = await github.get_repo_details(owner, repo_name)
            issues = await github.get_open_issues(owner, repo_name, per_page=20)

            solver = IssueSolver(llm=llm, github=github)
            solvable = solver.filter_solvable(issues, max_complexity=3)[:max_issues]

            console.print(f"Found [bold]{len(issues)}[/bold] open issues")
            console.print(f"[green]{len(solvable)}[/green] are solvable\n")

            if not solvable:
                console.print("[dim]No solvable issues found.[/dim]")
                return

            table = Table(title="🎯 Solvable Issues", show_lines=True)
            table.add_column("#", width=5)
            table.add_column("Category", width=12)
            table.add_column("Title", width=40)
            table.add_column("Labels", width=15)

            for issue in solvable:
                cat = solver.classify_issue(issue)
                table.add_row(
                    str(issue.number),
                    cat.value,
                    issue.title[:40],
                    ", ".join(issue.labels[:2]) or "-",
                )

            console.print(table)

        finally:
            await github.close()
            await llm.close()

    asyncio.run(_solve())


@cli.command()
@click.option("--status-filter", "-s", default=None, help="Filter by PR status")
@click.pass_context
def status(ctx, status_filter):
    """Show status of submitted pull requests."""
    print_banner()

    config = load_config(ctx.obj["config_path"])

    from contribai.orchestrator.memory import Memory

    async def _show():
        memory = Memory(config.storage.resolved_db_path)
        await memory.init()
        prs = await memory.get_prs(status=status_filter)
        await memory.close()
        return prs

    prs = asyncio.run(_show())

    if not prs:
        console.print("[dim]No PRs found.[/dim]")
        return

    table = Table(title="📋 Submitted PRs", show_lines=True)
    table.add_column("#", width=5)
    table.add_column("Repository", width=25)
    table.add_column("Title", width=35)
    table.add_column("Status", width=10)
    table.add_column("URL", width=30)

    status_colors = {
        "open": "green",
        "merged": "magenta",
        "closed": "red",
        "pending": "yellow",
    }

    for pr in prs:
        color = status_colors.get(pr["status"], "white")
        table.add_row(
            str(pr["pr_number"]),
            pr["repo"],
            pr["title"][:35],
            f"[{color}]{pr['status'].upper()}[/{color}]",
            pr["pr_url"],
        )

    console.print(table)


@cli.command()
@click.pass_context
def stats(ctx):
    """Show overall ContribAI statistics."""
    print_banner()

    config = load_config(ctx.obj["config_path"])

    from contribai.orchestrator.memory import Memory

    async def _get_stats():
        memory = Memory(config.storage.resolved_db_path)
        await memory.init()
        s = await memory.get_stats()
        await memory.close()
        return s

    s = asyncio.run(_get_stats())

    console.print(
        Panel(
            f"📊 [bold]Total Runs[/bold]: {s['total_runs']}\n"
            f"🔬 [bold]Repos Analyzed[/bold]: {s['total_repos_analyzed']}\n"
            f"📤 [bold]PRs Submitted[/bold]: {s['total_prs_submitted']}\n"
            f"✅ [bold]PRs Merged[/bold]: {s['prs_merged']}",
            title="ContribAI Statistics",
        )
    )


@cli.command()
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def cleanup(ctx, yes):
    """🧹 Clean up forks created by ContribAI.

    Reads forks from ContribAI's database, checks live PR status,
    and deletes forks where all PRs are merged or closed.
    Forks with open PRs are kept.
    """
    print_banner()

    config = load_config(ctx.obj["config_path"])

    if not config.github.token:
        console.print("[red]❌ GitHub token not configured![/red]")
        sys.exit(1)

    from contribai.github.client import GitHubClient
    from contribai.orchestrator.memory import Memory

    async def _cleanup():
        memory = Memory(config.storage.resolved_db_path)
        await memory.init()
        github = GitHubClient(token=config.github.token)

        try:
            # Get all PRs from DB
            all_prs = await memory.get_prs(limit=1000)
            if not all_prs:
                console.print("[dim]No PRs in database. Nothing to clean up.[/dim]")
                return

            # Group by fork
            forks: dict[str, list[dict]] = {}
            for pr in all_prs:
                fork_name = pr.get("fork", "")
                if not fork_name:
                    continue
                forks.setdefault(fork_name, []).append(pr)

            if not forks:
                console.print("[dim]No forks recorded in database.[/dim]")
                return

            console.print(f"\n🔍 Found {len(forks)} fork(s) in database\n")

            safe_to_delete = []
            has_open = []

            for fork_name, prs in forks.items():
                console.print(f"📁 [bold]{fork_name}[/bold]")

                all_resolved = True
                for pr in prs:
                    repo = pr["repo"]
                    pr_num = pr["pr_number"]

                    # Check live status
                    try:
                        owner, name = repo.split("/", 1)
                        pr_data = await github._get(f"/repos/{owner}/{name}/pulls/{pr_num}")
                        live_status = pr_data.get("state", "unknown")
                        if pr_data.get("merged_at"):
                            live_status = "merged"

                        # Sync to DB
                        await memory.update_pr_status(repo, pr_num, live_status)

                        if live_status == "merged":
                            icon = "🟢"
                        elif live_status == "open":
                            icon = "🟡"
                            all_resolved = False
                        else:
                            icon = "🔴"

                        console.print(f"   PR #{pr_num}: {pr['title'][:50]} [{icon} {live_status}]")
                    except Exception:
                        console.print(f"   PR #{pr_num}: {pr['title'][:50]} [⚪ unknown]")

                if all_resolved:
                    console.print("   ✅ All PRs resolved — safe to delete")
                    safe_to_delete.append(fork_name)
                else:
                    console.print("   ⚠️  Has open PRs — keeping")
                    has_open.append(fork_name)
                console.print()

            # Summary
            console.print("━" * 60)
            if has_open:
                console.print(f"\n⚠️  [yellow]{len(has_open)} fork(s) with open PRs (kept)[/yellow]")
            if safe_to_delete:
                console.print(f"\n✅ [green]{len(safe_to_delete)} fork(s) safe to delete:[/green]")
                for f in safe_to_delete:
                    console.print(f"   - {f}")

                if not yes and not click.confirm(
                    f"\n🗑️  Delete {len(safe_to_delete)} fork(s)?", default=False
                ):
                    console.print("[dim]Cancelled.[/dim]")
                    return

                for f in safe_to_delete:
                    try:
                        import subprocess

                        result = subprocess.run(
                            ["gh", "repo", "delete", f, "--yes"],
                            capture_output=True,
                            text=True,
                            timeout=30,
                        )
                        if result.returncode == 0:
                            console.print(f"   ✅ Deleted {f}")
                        else:
                            console.print(f"   ❌ Failed: {result.stderr.strip()}")
                    except Exception as e:
                        console.print(f"   ❌ Failed to delete {f}: {e}")

                console.print("\n🎉 Cleanup done!")
            else:
                console.print("\n[dim]No forks to clean up.[/dim]")

        finally:
            await github.close()
            await memory.close()

    asyncio.run(_cleanup())


@cli.command("config")
@click.pass_context
def show_config(ctx):
    """Show current configuration."""
    config = load_config(ctx.obj["config_path"])
    console.print(
        Panel(
            f"[bold]GitHub[/bold]\n"
            f"  Token: {'****' + config.github.token[-4:] if config.github.token else 'NOT SET'}\n"
            f"  Max repos/run: {config.github.max_repos_per_run}\n"
            f"  Max PRs/day: {config.github.max_prs_per_day}\n\n"
            f"[bold]LLM[/bold]\n"
            f"  Provider: {config.llm.provider}\n"
            f"  Model: {config.llm.model}\n"
            f"  API Key: "
            f"{'****' + config.llm.api_key[-4:] if config.llm.api_key else 'NOT SET'}\n\n"
            f"[bold]Discovery[/bold]\n"
            f"  Languages: {', '.join(config.discovery.languages)}\n"
            f"  Stars: {config.discovery.stars_range}\n\n"
            f"[bold]Analysis[/bold]\n"
            f"  Analyzers: {', '.join(config.analysis.enabled_analyzers)}\n"
            f"  Threshold: {config.analysis.severity_threshold}\n\n"
            f"[bold]Pipeline[/bold]\n"
            f"  Max concurrent: {config.pipeline.max_concurrent_repos}\n"
            f"  Timeout/repo: {config.pipeline.timeout_per_repo_sec}s\n\n"
            f"[bold]Web Dashboard[/bold]\n"
            f"  Host: {config.web.host}:{config.web.port}\n\n"
            f"[bold]Scheduler[/bold]\n"
            f"  Enabled: {config.scheduler.enabled}\n"
            f"  Cron: {config.scheduler.cron}",
            title="ContribAI Configuration",
        )
    )


@cli.command("serve")
@click.option("--host", default=None, help="Host to bind to")
@click.option("--port", default=None, type=int, help="Port")
@click.pass_context
def serve(ctx, host, port):
    """Start the web dashboard server."""
    config = load_config(ctx.obj["config_path"])
    if host:
        config.web.host = host
    if port:
        config.web.port = port

    console.print(
        f"[bold]Starting ContribAI Dashboard[/bold] at http://{config.web.host}:{config.web.port}"
    )

    from contribai.web.server import run_server

    run_server(config)


@cli.command("schedule")
@click.option("--cron", default=None, help="Cron expression")
@click.pass_context
def schedule(ctx, cron):
    """Start the scheduler daemon for automated runs."""
    config = load_config(ctx.obj["config_path"])
    config.scheduler.enabled = True
    if cron:
        config.scheduler.cron = cron

    console.print(
        f"[bold]Starting ContribAI Scheduler[/bold]\n"
        f"  Cron: {config.scheduler.cron}\n"
        f"  Timezone: {config.scheduler.timezone}"
    )

    from contribai.scheduler.scheduler import (
        ContribScheduler,
    )

    sched = ContribScheduler(config)
    sched.start()


@cli.command("templates")
@click.option(
    "--type",
    "contrib_type",
    default=None,
    help="Filter by contribution type",
)
def list_templates(contrib_type):
    """List available contribution templates."""
    from contribai.templates.registry import (
        TemplateRegistry,
    )

    registry = TemplateRegistry()
    templates = registry.filter_by_type(contrib_type) if contrib_type else registry.list_all()

    if not templates:
        console.print("[yellow]No templates found[/yellow]")
        return

    table = Table(title="Contribution Templates")
    table.add_column("Name", style="cyan")
    table.add_column("Type", style="green")
    table.add_column("Severity")
    table.add_column("Description")
    table.add_column("Languages")

    for t in templates:
        table.add_row(
            t.name,
            t.type,
            t.severity,
            t.description,
            ", ".join(t.languages) if t.languages else "all",
        )

    console.print(table)


@cli.command("profile")
@click.argument("name")
@click.option(
    "--dry-run",
    is_flag=True,
    help="Analyze only, no PRs",
)
@click.option(
    "--list",
    "list_all",
    is_flag=True,
    help="List all profiles",
)
@click.pass_context
def run_profile(ctx, name, dry_run, list_all):
    """Run pipeline with a named profile."""
    from contribai.core.profiles import (
        get_profile,
        list_profiles,
    )

    if list_all or name == "list":
        profiles = list_profiles()
        table = Table(title="Contribution Profiles")
        table.add_column("Name", style="cyan")
        table.add_column("Description")
        table.add_column("Analyzers")
        table.add_column("Threshold")
        for p in profiles:
            table.add_row(
                p.name,
                p.description,
                ", ".join(p.analyzers),
                p.severity_threshold,
            )
        console.print(table)
        return

    profile = get_profile(name)
    if not profile:
        console.print(f"[red]Profile '{name}' not found[/red]")
        console.print("Available: " + ", ".join(p.name for p in list_profiles()))
        return

    console.print(f"[bold]Running with profile: {profile.name}[/bold]\n  {profile.description}")

    from contribai.core.profiles import apply_profile

    config = load_config(ctx.obj["config_path"])
    config_data = config.model_dump()
    config_data = apply_profile(config_data, profile)

    from contribai.core.config import ContribAIConfig

    config = ContribAIConfig(**config_data)

    if profile.dry_run or dry_run:
        dry_run = True

    from contribai.orchestrator.pipeline import (
        ContribPipeline,
    )

    pipeline = ContribPipeline(config)
    result = asyncio.run(pipeline.run(dry_run=dry_run))
    _print_result(result, dry_run)


def _print_result(result, dry_run: bool):
    """Print pipeline execution results."""

    console.print()
    console.print(
        Panel(
            f"📦 Repos analyzed: [bold]{result.repos_analyzed}[/bold]\n"
            f"🔍 Issues found: [bold]{result.findings_total}[/bold]\n"
            f"🛠️  Contributions generated: [bold]{result.contributions_generated}[/bold]\n"
            f"📤 PRs created: [bold]{result.prs_created}[/bold]"
            + (f"\n❌ Errors: [red]{len(result.errors)}[/red]" if result.errors else ""),
            title="✅ Pipeline Complete" + (" (DRY RUN)" if dry_run else ""),
        )
    )

    if result.prs:
        console.print("\n[bold]Created PRs:[/bold]")
        for pr in result.prs:
            console.print(f"  • [green]{pr.pr_url}[/green] - {pr.contribution.title}")

    if result.errors:
        console.print("\n[bold red]Errors:[/bold red]")
        for e in result.errors:
            console.print(f"  • {e}")


@cli.command("models")
@click.option("--task", default=None, help="Filter by task type")
@click.pass_context
def show_models(ctx, task):
    """List available models and their capabilities."""
    from contribai.llm.models import (
        ALL_MODELS,
        TaskType,
        get_models_for_task,
    )
    from contribai.llm.router import TaskRouter

    if task:
        try:
            tt = TaskType(task)
        except ValueError:
            console.print(
                f"[red]Unknown task type: {task}[/red]\n"
                f"Valid: {', '.join(t.value for t in TaskType)}"
            )
            return
        models = get_models_for_task(tt)
        console.print(f"\n[bold]Best models for [cyan]{task}[/cyan]:[/bold]\n")
    else:
        models = ALL_MODELS
        console.print("\n[bold]Available Models:[/bold]\n")

    table = Table()
    table.add_column("Model", style="cyan")
    table.add_column("Tier")
    table.add_column("Code", justify="right")
    table.add_column("Analysis", justify="right")
    table.add_column("Speed", justify="right")
    table.add_column("Cost (in/out)")
    table.add_column("Best For")

    for m in models:
        tier_color = {
            "pro": "red",
            "flash": "yellow",
            "lite": "green",
        }.get(m.tier.value, "white")

        table.add_row(
            m.display_name,
            f"[{tier_color}]{m.tier.value.upper()}[/{tier_color}]",
            str(m.coding),
            str(m.analysis),
            str(m.speed),
            f"${m.input_cost:.2f}/${m.output_cost:.2f}",
            ", ".join(t.value for t in m.best_for[:3]),
        )

    console.print(table)

    # Show default assignments
    router = TaskRouter()
    defaults = router.get_default_assignments()
    console.print("\n[bold]Default Task Assignments:[/bold]")
    for task_type, model_name in defaults.items():
        console.print(f"  {task_type}: [cyan]{model_name}[/cyan]")
    console.print()


@cli.command("interactive")
@click.pass_context
def interactive(ctx):
    """Interactive TUI mode for browsing and contributing."""
    from contribai.cli.tui import run_interactive

    config = load_config(ctx.obj["config_path"])
    run_interactive(config)


@cli.command("leaderboard")
@click.option(
    "--limit",
    default=20,
    help="Number of entries",
)
@click.pass_context
def show_leaderboard(ctx, limit):
    """Show contribution leaderboard and success rates."""
    from contribai.core.leaderboard import Leaderboard
    from contribai.orchestrator.memory import Memory

    async def _run():
        config = load_config(ctx.obj["config_path"])
        memory = Memory(config.storage.resolved_db_path)
        await memory.init()

        board = Leaderboard(memory._db)
        stats = await board.get_overall_stats()
        rankings = await board.get_repo_rankings(limit=limit)
        type_stats = await board.get_type_stats()

        console.print(
            Panel(
                f"Total PRs: [bold]{stats['total']}[/bold]\n"
                f"Merged: [green]{stats['merged']}[/green] | "
                f"Closed: [red]{stats['closed']}[/red] | "
                f"Open: [yellow]{stats['open']}[/yellow]\n"
                f"Merge Rate: [bold]{stats['merge_rate']}%[/bold]",
                title="Contribution Leaderboard",
            )
        )

        if rankings:
            table = Table(title="Repo Rankings")
            table.add_column("Repo", style="cyan")
            table.add_column("Total")
            table.add_column("Merged", style="green")
            table.add_column("Closed", style="red")
            table.add_column("Open", style="yellow")
            table.add_column("Rate")

            for r in rankings:
                rate_color = (
                    "green" if r.merge_rate >= 70 else "yellow" if r.merge_rate >= 40 else "red"
                )
                table.add_row(
                    r.repo,
                    str(r.total_prs),
                    str(r.merged),
                    str(r.closed),
                    str(r.open),
                    f"[{rate_color}]{r.merge_rate:.0f}%[/{rate_color}]",
                )
            console.print(table)

        if type_stats:
            table2 = Table(title="By Contribution Type")
            table2.add_column("Type", style="cyan")
            table2.add_column("Total")
            table2.add_column("Merged", style="green")
            table2.add_column("Rate")
            for t in type_stats:
                table2.add_row(
                    t.type,
                    str(t.total),
                    str(t.merged),
                    f"{t.merge_rate:.0f}%",
                )
            console.print(table2)

        await memory.close()

    asyncio.run(_run())


@cli.command("notify-test")
@click.pass_context
def notify_test(ctx):
    """Send a test notification to configured channels."""
    from contribai.notifications.notifier import (
        NotificationEvent,
        Notifier,
    )

    config = load_config(ctx.obj["config_path"])
    nc = config.notifications

    notifier = Notifier(
        slack_webhook=nc.slack_webhook,
        discord_webhook=nc.discord_webhook,
        telegram_token=nc.telegram_token,
        telegram_chat_id=nc.telegram_chat_id,
    )

    if not notifier.is_configured:
        console.print("[yellow]No notification channels configured in config.yaml[/yellow]")
        return

    async def _send():
        await notifier.notify(
            NotificationEvent(
                event_type="run_complete",
                title="Test Notification",
                message="ContribAI notifications working!",
            )
        )
        await notifier.close()

    asyncio.run(_send())
    console.print("[green]Test notification sent![/green]")


@cli.command("system-status")
@click.pass_context
def sysinfo(ctx):
    """Show ContribAI system status — memory, PRs, rate limits."""
    print_banner()

    config = load_config(ctx.obj["config_path"])

    async def _run():
        from contribai.orchestrator.memory import Memory

        memory = Memory(config.storage.resolved_db_path)
        await memory.init()

        console.print("[bold]📊 ContribAI Status[/bold]\n")

        # Memory stats
        stats_table = Table(title="Memory Database", show_header=True)
        stats_table.add_column("Metric", style="cyan")
        stats_table.add_column("Value", style="green")

        # Count repos
        cursor = await memory._db.execute("SELECT COUNT(*) FROM analyzed_repos")
        repo_count = (await cursor.fetchone())[0]
        stats_table.add_row("Repos analyzed", str(repo_count))

        # Count PRs
        cursor = await memory._db.execute("SELECT COUNT(*) FROM submitted_prs")
        pr_count = (await cursor.fetchone())[0]
        stats_table.add_row("PRs submitted", str(pr_count))

        # PR by status
        cursor = await memory._db.execute(
            "SELECT status, COUNT(*) FROM submitted_prs GROUP BY status"
        )
        for status_val, count in await cursor.fetchall():
            stats_table.add_row(f"  └─ {status_val}", str(count))

        # Outcome stats
        try:
            outcome_stats = await memory.get_outcome_stats()
            if outcome_stats:
                for outcome, count in outcome_stats.items():
                    if outcome == "avg_merge_rate":
                        stats_table.add_row("Avg merge rate", f"{count:.0%}")
                    else:
                        stats_table.add_row(f"Outcome: {outcome}", str(count))
        except Exception:
            pass

        # Findings cache
        cursor = await memory._db.execute("SELECT COUNT(*) FROM findings_cache")
        findings_count = (await cursor.fetchone())[0]
        stats_table.add_row("Cached findings", str(findings_count))

        console.print(stats_table)

        # Recent PRs
        cursor = await memory._db.execute(
            "SELECT repo, pr_number, title, status, type "
            "FROM submitted_prs ORDER BY id DESC LIMIT 10"
        )
        recent = await cursor.fetchall()
        if recent:
            console.print()
            pr_table = Table(title="Recent PRs (last 10)")
            pr_table.add_column("Repo", style="cyan")
            pr_table.add_column("#", style="yellow")
            pr_table.add_column("Title", max_width=40)
            pr_table.add_column("Status")
            pr_table.add_column("Type", style="dim")
            for row in recent:
                status_style = (
                    "green" if row[3] == "merged" else "red" if row[3] == "closed" else "yellow"
                )
                pr_table.add_row(
                    row[0],
                    str(row[1]),
                    row[2],
                    f"[{status_style}]{row[3]}[/{status_style}]",
                    row[4],
                )
            console.print(pr_table)

        # GitHub rate limit
        try:
            from contribai.github.client import GitHubClient

            gh = GitHubClient(token=config.github.token)
            remaining = await gh.check_rate_limit()
            console.print(f"\n🔑 GitHub API rate limit remaining: [bold]{remaining}[/bold]")
            await gh.close()
        except Exception:
            console.print("\n[dim]Could not check GitHub rate limit[/dim]")

        await memory.close()

    asyncio.run(_run())


if __name__ == "__main__":
    cli()
