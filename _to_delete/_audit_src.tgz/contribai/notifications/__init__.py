"""Notification system for ContribAI."""
