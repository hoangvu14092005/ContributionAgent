"""Contribution generation modules."""
