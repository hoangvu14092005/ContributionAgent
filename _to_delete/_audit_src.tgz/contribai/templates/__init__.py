"""Contribution templates system."""
