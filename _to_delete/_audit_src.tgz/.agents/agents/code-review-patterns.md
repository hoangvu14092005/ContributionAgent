---
description: Code Review Patterns – style, naming, complexity, and architecture review checklist
trigger: /code-review
---

# Code Review Patterns Reference

Companion to `.agents/agents/code-reviewer.md`. Quick checklist + patterns for consistent reviews.

## Style and Formatting

- **Line length**: ≤ 100 chars (ruff config)
- **Naming**: `snake_case` for functions/vars, `PascalCase` for classes, `UPPER_SNAKE_CASE` for constants
- **Imports**: absolute only, grouped (stdlib, third-party, local), alphabetized
- **Docstrings**: Google style with `Args:`, `Returns:`, `Raises:`

## Code Smell Checklist

### Functions
- [ ] < 50 lines
- [ ] < 5 arguments (use a dataclass for more)
- [ ] Single responsibility (one verb in the name)
- [ ] No side effects in getters
- [ ] No mutable default arguments (`def foo(items=[])`)

### Classes
- [ ] < 200 lines
- [ ] Public API has docstrings
- [ ] No god classes (mixing I/O + business logic + presentation)
- [ ] `__init__` is minimal; prefer `@dataclass`

### Modules
- [ ] < 400 lines (split if exceeded)
- [ ] Clear module-level docstring
- [ ] No circular imports
- [ ] Dependencies flow: `core ← llm/github ← analysis/generator ← orchestrator ← cli`

### Async
- [ ] All I/O is `async/await`
- [ ] No `asyncio.run` inside coroutines
- [ ] No blocking calls in async paths (`time.sleep`, `requests`, `open()`)
- [ ] Use `aiofiles` for file I/O

### Error Handling
- [ ] No bare `except:` (always specify exception type)
- [ ] Custom exception types for domain errors (see `contribai/core/exceptions.py`)
- [ ] Errors logged with context (logger, not print)
- [ ] User-facing messages don't leak stack traces

## Naming Cheatsheet

| Want to name | Use |
|--------------|-----|
| A function | verb phrase: `compute_score`, `fetch_pr` |
| A predicate | `is_*`, `has_*`, `can_*`: `is_valid`, `has_license` |
| A class | noun phrase: `ContributionEngine` |
| A constant | `UPPER_SNAKE_CASE`: `MAX_RETRIES` |
| A module | lowercase, singular: `analyzer.py`, not `analyzers.py` |
| A test | `test_<unit>_<scenario>`: `test_score_empty_input` |

## Anti-Patterns (instant reject)

1. **God function**: > 100 lines, > 5 branches
2. **Copy-paste**: identical blocks > 10 lines in 2+ places
3. **Magic numbers**: `if retries > 3` should be `if retries > MAX_RETRIES`
4. **String-typed enums**: use `enum.Enum`, not raw strings
5. **Global mutable state**: singletons that hide state
6. **Catch-all exceptions**: `except Exception` swallowing the traceback

## Comment Quality

### ❌ Bad comments
```python
# Increment counter
counter += 1

# This is a hack but works
result = data[::-1]  # reverse
```

### ✅ Good comments
```python
# API caps retries at 3; see https://docs.example.com/rate-limit
MAX_RETRIES = 3

# Reverse to process most recent first; older items have stable positions
result = data[::-1]
```

## Review Etiquette

- Use severity labels: `nit:`, `suggestion:`, `issue:`, `question:`, `blocker:`
- Suggest, don't demand: "Consider using X because Y"
- Acknowledge good work: "Nice use of the strategy pattern here"
- Re-review promptly when author pushes fixes