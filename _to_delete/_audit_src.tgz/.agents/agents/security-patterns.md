---
description: Security Patterns – core security principles and OWASP-aligned review checklist for ContribAI
trigger: /security
---

# Security Patterns Reference

Companion to `.agents/agents/security-engineer.md`. This file is the **quick checklist** to consult whenever you touch authentication, file I/O, network calls, or LLM output handling.

## Core Security Principles

1. **Always use secure communication protocols** (HTTPS, SSH, never plain HTTP/FTP for credentials)
2. **Never store sensitive data in code or version control** — environment variables, secret managers only
3. **Validate ALL inputs** — including LLM output, file paths from external sources, URL params
4. **Treat LLM output as untrusted** — never `eval()`, never `exec()`, never `yaml.load()` on model output
5. **Log security-relevant events** — auth attempts, secret access, file operations

## OWASP Top 10 Checklist (apply when relevant)

| Category | What to check | ContribAI relevance |
|----------|---------------|---------------------|
| **A01 Broken Access Control** | Token scopes, role checks | GitHub token has `repo` + `read:org` only |
| **A02 Cryptographic Failures** | TLS, hashing | Use `httpx` with TLS verify on; `bcrypt` for secrets if stored |
| **A03 Injection** | SQL, command, prompt | aiosqlite parameterized queries; no `shell=True`; prompt templates vetted |
| **A04 Insecure Design** | Threat model, trust boundaries | LLM is untrusted boundary; sandbox untrusted code |
| **A05 Security Misconfig** | Defaults, debug mode | Production: `debug=False`; no stack traces in API errors |
| **A06 Vulnerable Components** | CVEs | `pip audit` in CI; pin major versions |
| **A07 Auth Failures** | Sessions, tokens | Rotate GitHub tokens; no long-lived bearer tokens |
| **A08 Data Integrity** | Deserialization, signatures | `yaml.safe_load`, `json.loads` (not `pickle`); DCO signoff on all PRs |
| **A09 Logging Failures** | Auditing | Log auth attempts, secret access, file deletes |
| **A10 SSRF** | URL fetching | Validate URL hosts before fetching; block private IP ranges |

## Common gotchas in ContribAI

### ❌ Never do this
```python
# Path traversal from LLM output
user_path = llm_output["file_path"]
with open(user_path) as f:  # BAD: no validation
    ...

# Command injection
os.system(f"git checkout {branch_name}")  # BAD

# Unsafe deserialization
import pickle
data = pickle.loads(untrusted_blob)  # BAD

# Hardcoded secret
api_key = "ghp_xxxxxxxxxxxxxxxxxxxx"  # BAD
```

### ✅ Always do this
```python
# Validate file paths against repo root
from pathlib import Path
safe_path = (repo_root / user_path).resolve()
if not safe_path.is_relative_to(repo_root):
    raise ValueError("Path escapes repo")

# Use subprocess with list args
subprocess.run(["git", "checkout", branch_name], check=True)

# Use yaml.safe_load
data = yaml.safe_load(text)

# Load secrets from env
api_key = os.environ["GITHUB_TOKEN"]
```

## Secret handling
- Local dev: `.env` (gitignored)
- CI: GitHub Actions secrets
- Runtime: read once at startup, never log
- Rotate immediately if a secret leaks

## When in doubt
1. Check `SECURITY.md` for disclosure policy
2. Look at how similar code already in the repo handles it
3. Ask the security-engineer agent before merging