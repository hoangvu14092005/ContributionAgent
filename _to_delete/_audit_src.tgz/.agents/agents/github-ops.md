---
description: GitHub Operations – how to use gh CLI and GitHub REST API correctly in ContribAI
trigger: /github
---

# GitHub Operations Reference

How ContribAI talks to GitHub. Read this before any PR/issue/repo API call.

## Auth
- `gh auth status` — check current auth
- `gh auth login --with-token < token.txt` — CI auth
- Required token scopes for ContribAI:
  - `repo` — read/write code, issues, PRs
  - `read:org` — list org repos
  - `workflow` — only if triggering Actions

## Common `gh` commands

```bash
# View PR
gh pr view 123 --repo owner/repo --json title,body,files,additions

# List PR comments (review threads)
gh api repos/owner/repo/pulls/123/comments --paginate

# List issue comments (general PR conversation)
gh api repos/owner/repo/issues/123/comments --paginate

# Reply to a PR
gh pr comment 123 --repo owner/repo --body "..."

# Edit PR description
gh pr edit 123 --repo owner/repo --body "$(cat desc.md)"

# Merge PR
gh pr merge 123 --repo owner/repo --squash --delete-branch

# Search repos
gh search repos "language:python stars:>1000" --limit 20 --json fullName,description

# List open issues
gh issue list --repo owner/repo --label good-first-issue --limit 30 --json number,title,labels
```

## REST API patterns

### Pagination
GitHub returns 30 items per page by default (max 100). Use `--paginate`:
```bash
gh api repos/owner/repo/issues --paginate \
  --jq '.[] | select(.state == "open") | {number, title}'
```

### Conditional requests (rate limit friendly)
```bash
# Use ETags to avoid re-fetching unchanged data
ETAG=$(gh api repos/owner/repo -I | grep -i etag | awk '{print $2}' | tr -d '\r')
gh api repos/owner/repo -H "If-None-Match: $ETAG"
```

### Rate limit awareness
```bash
gh api rate_limit --jq '.resources.core.remaining'
```
- 5000 req/hour for authenticated requests
- Use `X-RateLimit-Reset` header to schedule retries

## Webhook → polling fallback

If a webhook is unavailable, poll:
```bash
# Poll every 60s for new comments
while true; do
  gh api repos/owner/repo/pulls/123/comments --jq '.[].id' | sort -u > /tmp/seen
  comm -13 /tmp/seen /tmp/last_seen
  sleep 60
done
```

## Error handling

| Status | Meaning | Action |
|--------|---------|--------|
| 401 | Bad token | Re-auth, check scopes |
| 403 rate limit | Wait until `X-RateLimit-Reset` | Backoff, then retry |
| 404 | Repo/PR not found | Verify owner/repo and number |
| 422 | Validation failed | Read response body for fields |
| 5xx | GitHub issue | Retry with exponential backoff (max 3) |

## ContribAI integration

`contribai/github/client.py` wraps these into async methods:
- `list_assigned_issues()`
- `create_or_update_file()`
- `create_pull_request()`
- `get_pr_feedback()`
- `post_pr_comment()`

Always prefer these wrappers over raw `gh` calls — they handle auth, retry, and rate limiting.