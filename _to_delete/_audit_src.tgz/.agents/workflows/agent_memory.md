---
description: Agent Memory – maintain per-repo memory at .agents/agents/memory/<repo>.md with user confirmation
trigger: /remember
inputs:
  - name: ACTION
    description: "One of: list, add, remove, show"
    type: string
  - name: REPO_NAME
    description: "owner/repo identifier (optional for list)"
    type: string
---

# Agent Memory Workflow

Store and retrieve repository-specific knowledge that should outlive a single conversation. Inspired by OpenHands' `.openhands/microagents/repo.md` pattern, adapted for ContribAI's `.agents/` directory.

## When to use
- You learned a non-obvious project convention worth remembering
- You want to share context with future agents on the same repo
- You're onboarding to a repo and want to capture tribal knowledge

## Storage layout
```
.agents/
├── agents/memory/
│   ├── chinhkrb113_ContribAI.md
│   ├── python_cpython.md
│   └── ...
```

File naming: `<owner>_<repo>.md` (slash → underscore).

## Steps

### List memory files
```bash
ls .agents/agents/memory/
```

### Add new memory
1. Gather facts in 4 buckets:
   - Repository structure (top-level dirs, key modules)
   - Common commands (build, lint, test, pre-commit)
   - Code style preferences (line length, import order, type hint policy)
   - Workflows and best practices (PR rules, release flow, on-call rotation)

2. Show the user the items you plan to save:
   > "I'll save these items to `.agents/agents/memory/{{ REPO_NAME }}.md`:
   > 1. ...
   > 2. ...
   > May I save them?"

3. Only save what the user approves.

4. Write the file:
```markdown
---
repo: {{ REPO_NAME }}
description: <one-line summary>
updated: YYYY-MM-DD
---

# Memory for {{ REPO_NAME }}

## Structure
- ...

## Commands
- ...

## Style
- ...

## Workflows
- ...
```

### Show memory
```bash
cat .agents/agents/memory/{{ REPO_NAME }}.md
```

### Remove memory
```bash
rm .agents/agents/memory/{{ REPO_NAME }}.md
```

## Important rules
- NEVER save issue-specific debugging (one-off errors and their fixes)
- ALWAYS ask before persisting
- ONLY save things that would help a *different future task*
- If the memory grows past 500 lines, split into topic files

## Related ContribAI components
- `contribai/orchestrator/memory.py` — runtime working memory (different from this file)
- `contribai/agents/skill_loader.py` — programmatic access to `.agents/` files