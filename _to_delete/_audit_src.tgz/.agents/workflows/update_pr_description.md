---
description: Update PR description – refresh the PR body to reflect current diff
trigger: /update_pr_description
inputs:
  - name: PR_URL
    description: "URL of the pull request (https://github.com/owner/repo/pull/N)"
    type: string
    validation:
      pattern: "^https://github.com/.+/.+/pull/[0-9]+$"
  - name: BRANCH_NAME
    description: "Branch name corresponding to the pull request"
    type: string
---

# Update PR Description Workflow

Keep a PR's description aligned with the actual code changes. Use when the diff has grown beyond what the original description covers.

## When to use
- New commits added significant code that the description doesn't mention
- The original description was a stub (e.g. "WIP")
- Reviewer asked to clarify what the PR does
- Force-push after rebase changed the file list

## Steps

1. **Check out the branch**
```bash
git fetch origin {{ BRANCH_NAME }}
git checkout {{ BRANCH_NAME }}
```

2. **Compute the cumulative diff vs. main**
```bash
git diff origin/main...HEAD --stat
git diff origin/main...HEAD --name-only
```

3. **Read the existing PR description**
```bash
gh pr view {{ PR_URL }} --json title,body,files,additions,deletions
```

4. **Draft a new description**
Structure:
- **Summary** (1–3 sentences): what + why
- **Changes** (bullet list): main edits per file
- **Test plan**: how you verified
- **Related issues**: `Closes #N` / `Refs #N`

If the original description is empty or stale, write from scratch.

5. **Update the PR**
```bash
gh pr edit {{ PR_URL }} --body "$(cat /tmp/new_description.md)"
```
Or via the REST API:
```bash
gh api -X PATCH repos/{owner}/{repo}/issues/{number} \
  -f body="$(cat /tmp/new_description.md)"
```

6. **Verify**
```bash
gh pr view {{ PR_URL }} --json body
```

## Tips
- Keep the description under 4000 chars
- Use conventional commit message style for the summary
- Reference issues with `Closes`, `Fixes`, or `Refs` keywords
- Don't include test output or screenshots — those belong in the PR comment thread