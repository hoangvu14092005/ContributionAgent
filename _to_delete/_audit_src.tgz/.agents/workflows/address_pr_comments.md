---
description: Address PR comments – read review feedback via GitHub API and reply with code fixes
trigger: /address_pr_comments
inputs:
  - name: PR_URL
    description: "URL of the pull request"
    type: string
  - name: BRANCH_NAME
    description: "Branch name corresponding to the pull request"
    type: string
---

# Address PR Comments Workflow

Read review feedback on a PR and produce targeted replies + code fixes.

## When to use
- A maintainer or bot (Coderabbit, etc.) left review comments
- CI failed and a reviewer asked for changes
- You want to respond to inline review threads on an existing ContribAI PR

## Steps

1. **Fetch the branch locally**
```bash
git fetch origin {{ BRANCH_NAME }}
git checkout {{ BRANCH_NAME }}
```

2. **Read the diff against main**
```bash
git diff origin/main...HEAD --stat
git diff origin/main...HEAD
```
Understand the intent of the changes before responding.

3. **List review comments via GitHub API**
```bash
gh api repos/{owner}/{repo}/pulls/{{ PR_URL ## /pull/ ## }}comments --paginate
gh api repos/{owner}/{repo}/issues/{{ PR_URL ## /pull/ ## }}/comments --paginate
```
Collect: file, line, author, body, in_reply_to_id.

4. **Classify each comment**
- `nit:` / `suggestion:` — nice-to-have, may skip if low value
- `issue:` / `blocker:` — must address
- `question:` — answer with explanation, no code change
- `bot:` (Coderabbit, etc.) — read its original analysis via `in_reply_to_id`

5. **For each actionable comment, write a fix**
- Open the relevant file
- Make the minimal change requested
- Keep changes focused — don't refactor surrounding code
- Add/update tests if behavior changed

6. **Commit per fix (or batched)**
```bash
git add -A
git commit -s -m "fix: address review feedback — <short summary>"
```

7. **Reply on the PR thread**
```bash
gh pr comment {{ PR_URL }} --body "..."
```
Mention the file/line, describe the change, link the commit.

8. **Push and re-run CI**
```bash
git push origin {{ BRANCH_NAME }}
```
Watch CI; if new comments appear, loop back to step 3.

## Related ContribAI components
- `contribai/pr/patrol.py` — auto-monitors PRs (extends with active replies)
- `contribai/core/models.py` — `FeedbackItem`, `FeedbackAction`
- `contribai/github/client.py` — `create_or_update_file`, comment helpers