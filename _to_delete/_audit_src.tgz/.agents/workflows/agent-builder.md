---
description: Agent Builder – interview user with progressive questions and design a new agent for ContribAI
trigger: /agent-builder
inputs:
  - name: INITIAL_PROMPT
    description: "Initial description of what agent the user wants to build"
    type: string
---

# Agent Builder Workflow

Progressively interview the user (≤ 5 questions) to understand the agent they need, then design and scaffold a new agent file in `.agents/agents/` or `.agents/workflows/`.

## When to use
- Adding a new specialist role (e.g. `i18n-engineer.md`)
- Codifying a recurring workflow as a reusable skill
- A reviewer asks "can we automate X?"

## Steps

1. **Acknowledge the initial prompt**
> You said: "{{ INITIAL_PROMPT }}"

2. **Interview (≤ 5 progressive questions, each ≤ 2 sentences)**
Suggested first question if prompt is empty:
> "What recurring task do you wish ContribAI could handle automatically?"

Examples of follow-ups (pick the most relevant):
- What triggers the agent? (PR event, schedule, manual command, webhook)
- What inputs does it need? (repo name, file path, PR number, free-form prompt)
- What outputs does it produce? (code change, comment, status update, new file)
- Does it call external services? (GitHub API, LLM, Docker)
- What's the success criterion? (CI green, comment posted, file created)

3. **Confirm understanding**
> "So the agent should `<restated behavior>` when `<trigger>`, producing `<output>`. Correct?"

4. **Choose the file type**
- **Persona/role** → `.agents/agents/<name>.md`
- **Procedural steps** → `.agents/workflows/<name>.md`
- **Reference knowledge** → `.agents/knowledge/<name>.md`

5. **Scaffold the file**
Use the template at `external/notes/agent-template.md` (or copy an existing file of the same type).

Frontmatter required:
```yaml
---
description: <one-line summary>
trigger: /<command-name>
inputs:
  - name: <PARAM>
    type: string
---
```

6. **Register the trigger**
If programmatic invocation is needed, add the trigger to `contribai/agents/skill_loader.py` and expose via `contribai skills find /<command-name>`.

7. **Add a smoke test**
See `tests/unit/test_skill_loader.py` for the parsing test pattern.

8. **Update AGENTS.md**
Add the new entry under "Agents" or "Workflows".

## Guardrails
- Max 5 questions — stop early once you have enough
- Don't write the agent's body during interview; design first, implement after approval
- Reuse existing components when possible (don't create new LLM clients, registry entries, etc.)