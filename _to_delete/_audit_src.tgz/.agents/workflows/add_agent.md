---
description: Add Agent – guided creation of a new agent or workflow file in .agents/
trigger: /add_agent
inputs:
  - name: AGENT_TYPE
    description: "One of: persona, workflow, knowledge"
    type: string
  - name: AGENT_NAME
    description: "kebab-case filename without extension, e.g. backend-dev"
    type: string
---

# Add Agent Workflow

Guided creation of a new `.agents/` file using the project's templates. Extends `/agent-builder` with concrete templates and validation.

## When to use
- You want a quickstart template rather than designing from scratch
- The agent is one of the three standard types: persona / workflow / knowledge
- You want frontmatter validated against the schema

## Steps

1. **Pick the type** — `{{ AGENT_TYPE }}` must be one of:
   - `persona` → goes to `.agents/agents/<name>.md`
   - `workflow` → goes to `.agents/workflows/<name>.md`
   - `knowledge` → goes to `.agents/knowledge/<name>.md`

2. **Validate the name** — must be kebab-case: `^[a-z0-9]+(-[a-z0-9]+)*$`

3. **Apply the template**

**Persona template:**
```markdown
---
description: <Role Name> – <one-line summary>
---

# <Role Name> Agent

## Role
You are the **<Role Name>** of ContribAI. <what you do>.

## Responsibilities
1. ...

## Standards
- ...

## Files Owned
- ...
```

**Workflow template:**
```markdown
---
description: <Workflow Name> – <one-line summary>
trigger: /<command-name>
inputs:
  - name: <PARAM>
    type: string
---

# <Workflow Name> Workflow

## Steps
1. **<step title>**
```bash
<command>
```
...

## Related components
- ...
```

**Knowledge template:**
```markdown
---
description: <Topic> – <one-line summary>
---

# <Topic>

## When to apply
...

## Patterns
- ...
```

4. **Place the file**
```bash
# Persona
mv new.md .agents/agents/{{ AGENT_NAME }}.md

# Workflow
mv new.md .agents/workflows/{{ AGENT_NAME }}.md

# Knowledge
mv new.md .agents/knowledge/{{ AGENT_NAME }}.md
```

5. **Verify the loader picks it up**
```bash
contribai skills list
contribai skills find /<command-name>
```

6. **Add a smoke test**
Add the new file's `description` to the `test_skill_loader.py` allow-list.

## Templates live at
`external/notes/agent-templates/` (one file per type)