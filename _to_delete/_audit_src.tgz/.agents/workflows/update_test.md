---
description: Update tests – fix failing tests to match current implementation when behavior has intentionally changed
trigger: /update_test
inputs:
  - name: BRANCH_NAME
    description: "Branch for the agent to work on"
    type: string
  - name: TEST_COMMAND_TO_RUN
    description: "The test command to run, e.g. pytest tests/unit/test_bash_parsing.py"
    type: string
---

# Update Test Workflow

When implementation is intentionally correct and tests are stale, update the tests to match the new behavior — not the other way around.

## When to use
- A behavior change is intentional (e.g. deprecation, API rename)
- Test expects the old output but the implementation now returns the new output
- A test fixture references a removed/renamed symbol
- You're migrating tests from one framework to another

## When NOT to use
- The implementation has a bug → fix the implementation, not the test
- The test is checking a real invariant → don't loosen the assertion
- The test is just flaky → fix the flakiness, don't delete the test

## Steps

1. **Check out the branch**
```bash
git fetch origin {{ BRANCH_NAME }}
git checkout {{ BRANCH_NAME }}
```

2. **Run the failing test**
```bash
{{ TEST_COMMAND_TO_RUN }} -v --tb=long
```
Capture the actual output.

3. **Read the implementation**
Find the function/class the test targets. Confirm the new behavior is intentional:
- Look at git log for that file
- Check related PRs/issues
- If unsure, ASK before modifying the test

4. **Update only the relevant assertions**
- Replace outdated expected values with new ones
- Add a comment explaining the intent: `# Updated for v2 API: see commit abc123`
- Keep the test's intent intact — test the same *property*, just with new *data*

5. **Add coverage for the new behavior**
If the behavior change introduced a new edge case, add a new test rather than just rewriting the old one.

6. **Re-run the full test suite**
```bash
pytest tests/ -v --tb=short
```
Make sure no other tests broke.

7. **Commit**
```bash
git add tests/
git commit -s -m "test: update tests for <feature> behavior change"
```

## Related ContribAI components
- `tests/unit/test_*.py` — unit tests
- `tests/integration/` — integration tests
- `contribai/sandbox/sandbox.py` — sandbox validation (run tests in Docker for safety)