---
description: Default Tools – MCP stdio servers and tools auto-loaded for every ContribAI session
trigger: /default-tools
type: knowledge
---

# Default Tools (MCP stdio servers)

Tools auto-injected into every ContribAI agent invocation. Inspired by OpenHands' `default-tools.md` repo microagent.

## Currently configured

```yaml
# contribai config.yaml
mcp:
  stdio_servers:
    - name: fetch
      command: uvx
      args: ["mcp-server-fetch"]
    - name: github
      command: uvx
      args: ["mcp-server-github"]
    - name: filesystem
      command: uvx
      args: ["mcp-server-filesystem"]
```

## How it works

1. On agent startup, `contribai/mcp/mcp_client.py` reads the `mcp.stdio_servers` list
2. Each server is spawned as a subprocess via `stdio`
3. The server's `tools/list` response is merged into the agent's tool pool
4. `tools/call` requests are routed back to the appropriate subprocess

## When tools are loaded

| Scope | Loaded when | File |
|-------|-------------|------|
| **Global** | Every ContribAI session | `config.yaml` → `mcp.stdio_servers` |
| **Per-repo** | Working in that repo | `.agents/knowledge/repo-tools.md` (if present) |
| **Per-agent** | Specific agent runs | `contribai/agents/<name>.md` frontmatter |

## Adding a new default tool

1. Find or build an MCP server for the tool
2. Add to `config.yaml`:
   ```yaml
   mcp:
     stdio_servers:
       - name: <tool-name>
         command: <executable>
         args: [<arg1>, <arg2>]
   ```
3. Test locally:
   ```bash
   contribai mcp test <tool-name>
   ```
4. Document in this file
5. Update CHANGELOG.md

## Safety

- MCP servers run with the same privileges as the ContribAI process
- NEVER add a server that accepts arbitrary URLs without allowlisting
- NEVER pipe `mcp-server-*` to a public network without auth
- Review the server's source code if it's not from a trusted publisher

## Bundled with ContribAI

14 tools are exposed via the local MCP server (`contribai/mcp_server.py`):
- `analyze_repo`
- `generate_fix`
- `submit_pr`
- `patrol_prs`
- `solve_issue`
- `get_repo_intel`
- `create_or_update_file`
- `list_assigned_issues`
- `get_pr_feedback`
- `post_pr_comment`
- `run_tests`
- `lint_code`
- `format_code`
- `get_pipeline_status`

See `contribai/mcp_server.py` for the full list.